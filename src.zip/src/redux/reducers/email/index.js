import { combineReducers } from "redux"
import mails from "./emails"

const emailReducer = combineReducers({
  mails
})

export default emailReducer
